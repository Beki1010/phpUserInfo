const ua = detect.parse(navigator.userAgent);
const button = document.querySelector('.download');
const devicename = document.querySelector('.deviceName');


console.log(ua.device);
if(ua.device !== null){
    if(ua.device.family === 'iPhone')
    {
        button.textContent = 'Download Mobile App';
        devicename.textContent = "iPhone";
    }else{
        devicename.textContent = ua.device.family;
    }

    devicename.textContent = ua.device.family;
    deviceBrowser.textContent = ua.device.browser;
    // deviceBrowser.textContent = ua.device.browser;
    deviceOsFamily.textContent = ua.os.family;
    ua.toString();
    ua.toVersionString();
    
}