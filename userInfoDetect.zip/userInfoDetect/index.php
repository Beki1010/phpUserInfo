<?php 
    require "UserInfo.php";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- <link href="css/style.css" rel="stylesheet"> -->
    </head>
    <body>
    <div class="container">

    <h1>Detect User</h1>
    <a href="" class="download">start</a>
    <h5> Device Family: <span class="deviceName"></span> Detected!</h5> 
    <h5> Device Browser: <span class="deviceBrowser"></span> Detected!</h5> 
    <h5> Device Os Family: <span class="deviceOsFamily"></span> Detected!</h5> 


    </div>
    <script src="./detect.min.js"></script>
    <script src="./main.js"></script>
    </body>
</html>